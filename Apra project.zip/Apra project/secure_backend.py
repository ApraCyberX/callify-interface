import sqlite3
import subprocess
import datetime

DB_FILE = "secure_exec.db"


# ---------- DATABASE INIT ---------- #
def init_db():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()

    cur.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        role TEXT
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS executions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT,
        username TEXT,
        command TEXT,
        result TEXT,
        allowed INTEGER
    )""")

    cur.execute("SELECT COUNT(*) FROM users")
    if cur.fetchone()[0] == 0:
        cur.execute("INSERT INTO users(username,password,role) VALUES (?,?,?)",
                    ("Apra", "123@123", "admin"))
        cur.execute("INSERT INTO users(username,password,role) VALUES (?,?,?)",
                    ("user", "user@123", "user"))

    conn.commit()
    conn.close()


# ---------- LOGIN ---------- #
def authenticate(username, password):
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("SELECT role FROM users WHERE username=? AND password=?",
                (username, password))
    data = cur.fetchone()
    conn.close()
    if data:
        return data[0]
    return None


# ---------- SECURE COMMAND EXECUTION ---------- #
def secure_execute(username, cmd):
    allowed_cmds = ["echo", "dir", "ipconfig", "ping"]
    base = cmd.split()[0].lower()
    allowed = 1 if base in allowed_cmds else 0

    if allowed:
        result = subprocess.getoutput(cmd)
    else:
        result = "BLOCKED - Command Not Allowed!"

    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("INSERT INTO executions(timestamp,username,command,result,allowed) VALUES (?,?,?,?,?)",
                (datetime.datetime.now(), username, cmd, result, allowed))
    conn.commit()
    conn.close()

    return result


# ---------- EXECUTION HISTORY ---------- #
def get_history():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("SELECT timestamp, username, command, result, allowed FROM executions ORDER BY id DESC")
    rows = cur.fetchall()
    conn.close()
    return rows


# ---------- USER MANAGEMENT (ADMIN) ---------- #
def create_user(username: str, password: str, role: str):
    if not username or not password:
        return False, "Username/Password required"

    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
            (username, password, role)
        )
        conn.commit()
        return True, "User Created Successfully!"
    except sqlite3.IntegrityError:
        return False, "Username Already Exists!"
    finally:
        conn.close()


def get_all_users():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("SELECT id, username, role FROM users ORDER BY id DESC")
    rows = cur.fetchall()
    conn.close()
    return rows


def delete_user(uid: int):
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("DELETE FROM users WHERE id=?", (uid,))
    conn.commit()
    conn.close()
    return True, "User Removed!"


# Initialize DB when imported
init_db()
